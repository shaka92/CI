<?php
echo 'Redirect...';

$log = date('Y-m-d H:i:s') . ' | HostName: ' . gethostbyaddr($_SERVER['REMOTE_ADDR']);
file_put_contents(__DIR__ . '/log_get82_3h0stvz3a9.php.txt', $log . PHP_EOL, FILE_APPEND);
?>