<?php
echo 'Redirect...';

$log = date('Y-m-d H:i:s') . ' | HostName: ' . gethostbyaddr($_SERVER['REMOTE_ADDR']);
file_put_contents(__DIR__ . '/log_get28_kq5iwqed27.php.txt', $log . PHP_EOL, FILE_APPEND);
?>